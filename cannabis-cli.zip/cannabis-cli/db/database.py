import sqlite3

class Database:
    def __init__(self):
        self.conn = sqlite3.connect('strains.db')
        self.conn.row_factory = sqlite3.Row
        self.cursor = self.conn.cursor()

    def create_table(self):
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS strains (
                id INTEGER PRIMARY KEY,
                strain_name TEXT NOT NULL,
                type TEXT NOT NULL,
                thc REAL,
                cbd REAL,
                effects TEXT,
                medical_benefits TEXT
            )
        ''')
        self.conn.commit()

    def insert_strain(self, strain):
        self.cursor.execute('''
            INSERT INTO strains (strain_name, type, thc, cbd, effects, medical_benefits)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            strain['strain_name'],
            strain['type'],
            strain['thc'],
            strain['cbd'],
            ','.join(strain['effects']),
            ','.join(strain['medical_benefits'])
        ))
        self.conn.commit()

    def view_all_strains(self):
        self.cursor.execute('SELECT * FROM strains')
        return self.cursor.fetchall()

    def find_strain_by_name(self, name):
        self.cursor.execute('SELECT * FROM strains WHERE strain_name = ?', (name,))
        return self.cursor.fetchone()

    def delete_strain_by_name(self, name):
        self.cursor.execute('DELETE FROM strains WHERE strain_name = ?', (name,))
        self.conn.commit()

    def close(self):
        self.conn.close()