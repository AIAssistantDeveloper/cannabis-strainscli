import json
import yaml
from pathlib import Path

def load_data(file_path, file_type='json'):
    file_path = Path(file_path)
    
    if not file_path.exists():
        raise FileNotFoundError(f'{file_path} does not exist')

    with open(file_path, 'r') as file:
        if file_type == 'json':
            return json.load(file)
        elif file_type == 'yaml':
            return yaml.safe_load(file)
        else:
            raise ValueError('Unsupported file type. Use "json" or "yaml".')