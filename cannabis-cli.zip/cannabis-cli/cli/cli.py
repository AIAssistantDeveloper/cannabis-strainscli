import argparse
from db.database import Database
import json
import yaml

def add_strain_from_file(args):
    db = Database()
    with open(args.file, 'r') as f:
        if args.file_type == 'json':
            data = json.load(f)
        elif args.file_type == 'yaml':
            data = yaml.safe_load(f)
        else:
            raise ValueError("Unsupported file type")
    
    for strain in data:
        db.insert_strain(strain)
    db.close()
    print("Strains added successfully!")

def view_all_strains(args):
    db = Database()
    strains = db.view_all_strains()
    for strain in strains:
        print(dict(strain))
    db.close()

def search_strain(args):
    db = Database()
    result = db.find_strain_by_name(args.name)
    if result:
        print(dict(result))
    else:
        print("Strain not found.")
    db.close()

def create_parser():
    parser = argparse.ArgumentParser(description="Cannabis Strain CLI")
    
    subparsers = parser.add_subparsers(title='Commands', description='Available commands')

    # Command for adding strains from file
    parser_add = subparsers.add_parser('add', help='Add strains from a JSON or YAML file')
    parser_add.add_argument('--file', type=str, required=True, help='Path to the data file (json or yaml)')
    parser_add.add_argument('--file_type', type=str, default='json', help='File type (json or yaml)')
    parser_add.set_defaults(func=add_strain_from_file)

    # Command for viewing all strains
    parser_view = subparsers.add_parser('view', help='View all strains')
    parser_view.set_defaults(func=view_all_strains)

    # Command for searching a specific strain
    parser_search = subparsers.add_parser('search', help='Search for a strain by name')
    parser_search.add_argument('--name', type=str, required=True, help='Name of the strain')
    parser_search.set_defaults(func=search_strain)

    return parser

def main():
    parser = create_parser()
    args = parser.parse_args()
    args.func(args)

if __name__ == "__main__":
    main()