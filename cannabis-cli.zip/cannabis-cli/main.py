from cli.cli import create_parser

if __name__ == "__main__":
    parser = create_parser()
    args = parser.parse_args()
    
    # Check if any command was provided
    if hasattr(args, 'func'):
        args.func(args)
    else:
        parser.print_help()