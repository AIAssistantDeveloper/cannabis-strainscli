import unittest
from unittest.mock import patch
import os
import tempfile
import json
import yaml
from main import create_parser
from db.database import Database

class TestCLI(unittest.TestCase):
    def setUp(self):
        # Create a temporary directory for the database and data files
        self.test_dir = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.test_dir.name, 'test_strains.db')
        self.json_file_path = os.path.join(self.test_dir.name, 'test_strains.json')
        self.yaml_file_path = os.path.join(self.test_dir.name, 'test_strains.yaml')

        # Set up a test database
        self.db = Database()

        # Sample strain data for JSON and YAML files
        self.sample_data = [
            {
                "strain_name": "Test Strain 1",
                "type": "Hybrid",
                "thc": 18.5,
                "cbd": 0.1,
                "effects": ["Relaxed", "Euphoric"],
                "medical_benefits": ["Pain", "Stress"]
            },
            {
                "strain_name": "Test Strain 2",
                "type": "Indica",
                "thc": 20.0,
                "cbd": 0.2,
                "effects": ["Happy", "Hungry"],
                "medical_benefits": ["Depression", "Anxiety"]
            }
        ]

        # Write sample data to a JSON file
        with open(self.json_file_path, 'w') as json_file:
            json.dump(self.sample_data, json_file)

        # Write sample data to a YAML file
        with open(self.yaml_file_path, 'w') as yaml_file:
            yaml.safe_dump(self.sample_data, yaml_file)

    def tearDown(self):
        self.db.cursor.execute('DELETE FROM strains')  # Clean up the database after each test
        self.db.conn.commit()
        self.db.close()
        self.test_dir.cleanup()  # Remove temporary directory

    @patch('sys.argv', ['main.py', 'add', '--file', 'test_strains.json', '--file_type', 'json'])
    def test_add_strains_from_json(self):
        with patch('builtins.open', return_value=open(self.json_file_path)):
            parser = create_parser()
            args = parser.parse_args()
            args.func(args)
        
        # Verify that the strains were added to the database
        strains = self.db.fetch_all_strains()
        self.assertEqual(len(strains), 2)
        self.assertEqual(strains[0][1], "Test Strain 1")
        self.assertEqual(strains[1][1], "Test Strain 2")

    @patch('sys.argv', ['main.py', 'add', '--file', 'test_strains.yaml', '--file_type', 'yaml'])
    def test_add_strains_from_yaml(self):
        with patch('builtins.open', return_value=open(self.yaml_file_path)):
            parser = create_parser()
            args = parser.parse_args()
            args.func(args)

        # Verify that the strains were added to the database
        strains = self.db.fetch_all_strains()
        self.assertEqual(len(strains), 2)
        self.assertEqual(strains[0][1], "Test Strain 1")
        self.assertEqual(strains[1][1], "Test Strain 2")

    @patch('sys.argv', ['main.py', 'view'])
    def test_view_all_strains(self):
        # Insert sample strain data to the database
        for strain in self.sample_data:
            self.db.insert_strain(strain)
        
        with patch('builtins.print') as mock_print:
            parser = create_parser()
            args = parser.parse_args()
            args.func(args)
        
        # Check that the strains are printed
        self.assertEqual(mock_print.call_count, 2)  # 2 strains

    @patch('sys.argv', ['main.py', 'search', '--name', 'Test Strain 1'])
    def test_search_strain_by_name(self):
        # Insert sample strain data to the database
        for strain in self.sample_data:
            self.db.insert_strain(strain)
        
        with patch('builtins.print') as mock_print:
            parser = create_parser()
            args = parser.parse_args()
            args.func(args)
        
        # Check that the correct strain is printed
        mock_print.assert_called_with(self.db.find_strain_by_name('Test Strain 1'))

if __name__ == '__main__':
    unittest.main()