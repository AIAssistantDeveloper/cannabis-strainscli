import unittest
from db.database import Database

class TestDatabase(unittest.TestCase):
    def setUp(self):
        self.db = Database()
    
    def tearDown(self):
        self.db.cursor.execute('DELETE FROM strains')  # Clean up after each test
        self.db.conn.commit()
        self.db.close()

    def test_insert_strain(self):
        strain = {
            "strain_name": "TestBlue Dream",
            "type": "Hybrid",
            "thc": 18.5,
            "cbd": 0.1,
            "effects": ["Relaxed", "Happy"],
            "medical_benefits": ["Anxiety", "Pain"]
        }
        self.db.insert_strain(strain)
        
        # Verify the strain was inserted correctly
        result = self.db.find_strain_by_name("TestBlue Dream")
        self.assertIsNotNone(result)
        self.assertEqual(result['strain_name'], "Test Strain")
        self.assertEqual(result['type'], "Hybrid")
        self.assertEqual(result['thc'], 18.5)
        self.assertEqual(result['cbd'], 0.1)
        self.assertIn("Relaxed", result['effects'])
        self.assertIn("Happy", result['effects'])

    def test_view_all_strains(self):
        strain_1 = {
            "strain_name": "Strain 1",
            "type": "Indica",
            "thc": 20.0,
            "cbd": 0.2,
            "effects": ["Euphoric"],
            "medical_benefits": ["Stress"]
        }
        strain_2 = {
            "strain_name": "Strain 2",
            "type": "Sativa",
            "thc": 15.0,
            "cbd": 0.5,
            "effects": ["Energetic"],
            "medical_benefits": ["Depression"]
        }
        self.db.insert_strain(strain_1)
        self.db.insert_strain(strain_2)

        # Verify all strains are fetched
        strains = self.db.fetch_all_strains()
        self.assertEqual(len(strains), 2)
        self.assertEqual(strains[0]['strain_name'], "Strain 1")
        self.assertEqual(strains[1]['strain_name'], "Strain 2")

    def test_find_strain_by_name(self):
        strain = {
            "strain_name": "Unique Strain",
            "type": "Hybrid",
            "thc": 17.5,
            "cbd": 0.3,
            "effects": ["Calm"],
            "medical_benefits": ["Insomnia"]
        }
        self.db.insert_strain(strain)
        
        # Search for the strain by name
        result = self.db.find_strain_by_name("Unique Strain")
        self.assertIsNotNone(result)
        self.assertEqual(result['strain_name'], "Unique Strain")

    def test_find_strain_by_invalid_name(self):
        # Try to find a strain that does not exist
        result = self.db.find_strain_by_name("Non-existent Strain")
        self.assertIsNone(result)

    def test_delete_strain(self):
        strain = {
            "strain_name": "Test Strain to Delete",
            "type": "Sativa",
            "thc": 16.0,
            "cbd": 0.6,
            "effects": ["Focused"],
            "medical_benefits": ["Fatigue"]
        }
        self.db.insert_strain(strain)
        
        # Delete the strain
        self.db.delete_strain_by_name("Test Strain to Delete")
        
        # Verify the strain was deleted
        result = self.db.find_strain_by_name("Test Strain to Delete")
        self.assertIsNone(result)

if __name__ == '__main__':
    unittest.main()